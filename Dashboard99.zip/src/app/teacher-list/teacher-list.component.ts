import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-teacher-list',
  templateUrl: './teacher-list.component.html',
  styleUrls: ['./teacher-list.component.css']
})
export class TeacherListComponent implements OnInit {

  constructor( private aip:ApiService) { }
 teacherdata:any;

  ngOnInit(): void {
    this.aip.allTeacherData().subscribe((res)=>{
      this.teacherdata=res;
    })
    this.teacherdata;
  }

}
