import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-add-teachter',
  templateUrl: './add-teachter.component.html',
  styleUrls: ['./add-teachter.component.css']
})
export class AddTeachterComponent implements OnInit {

  constructor( private formbuilder:FormBuilder , private api:ApiService) { }
   formdata:any;
   loading:boolean=false;
   submitted:boolean=false;

  ngOnInit(): void {
    this.formdata=this.formbuilder.group({
      name:'',
      photo:'',
      email:'',
      subject:'',
      class:''
    });
  }
  get f(){
    return this.formdata.controls;
  }
  onSubmit(){
    this.submitted=true;
    if(this.formdata.invalid){
      return;
    }
    this.api.giveData(this.formdata.value).subscribe((res)=>{

    });
   console.log(this.formdata.value);
  }

}
