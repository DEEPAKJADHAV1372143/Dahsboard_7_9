import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTeachterComponent } from './add-teachter.component';

describe('AddTeachterComponent', () => {
  let component: AddTeachterComponent;
  let fixture: ComponentFixture<AddTeachterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddTeachterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTeachterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
