import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-d',
  templateUrl: './home-d.component.html',
  styleUrls: ['./home-d.component.css']
})
export class HomeDComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
