import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-teachter',
  templateUrl: './add-teachter.component.html',
  styleUrls: ['./add-teachter.component.css']
})
export class AddTeachterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
