import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AsideComponent } from './aside/aside.component';
import { HomeDComponent } from './home-d/home-d.component';
import { NewsComponent } from './news/news.component';
import { AdmissionComponent } from './admission/admission.component';
import { LoginComponent } from './login/login.component';
import { StudenListComponent } from './studen-list/studen-list.component';
import { AddTeachterComponent } from './add-teachter/add-teachter.component';
import { TeacherListComponent } from './teacher-list/teacher-list.component';
import { TeacherLoginComponent } from './teacher-login/teacher-login.component';
import { EventComponent } from './event/event.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    AsideComponent,
    HomeDComponent,
    NewsComponent,
    AdmissionComponent,
    LoginComponent,
    StudenListComponent,
    AddTeachterComponent,
    TeacherListComponent,
    TeacherLoginComponent,
    EventComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
