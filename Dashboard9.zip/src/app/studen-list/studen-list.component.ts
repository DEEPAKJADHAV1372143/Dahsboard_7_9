import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studen-list',
  templateUrl: './studen-list.component.html',
  styleUrls: ['./studen-list.component.css']
})
export class StudenListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
