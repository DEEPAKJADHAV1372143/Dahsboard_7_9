import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddTeachterComponent } from './add-teachter/add-teachter.component';
import { AdmissionComponent } from './admission/admission.component';
import { EventComponent } from './event/event.component';
import { HomeDComponent } from './home-d/home-d.component';
import { LoginComponent } from './login/login.component';
import { NewsComponent } from './news/news.component';
import { StudenListComponent } from './studen-list/studen-list.component';
import { TeacherListComponent } from './teacher-list/teacher-list.component';
import { TeacherLoginComponent } from './teacher-login/teacher-login.component';

const routes: Routes = [
  {path:'',component:HomeDComponent},
  {path:'home',component:HomeDComponent},
  {path:'news',component:NewsComponent},
  {path:'addmision',component:AdmissionComponent},
  {path:'login',component:LoginComponent},
  {path:'Student-list',component:StudenListComponent},
  {path:'add-Teacher',component:AddTeachterComponent},
  {path:'teacher-list',component:TeacherListComponent},
  {path:'teacher-login',component:TeacherLoginComponent},
  {path:'event',component:EventComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
