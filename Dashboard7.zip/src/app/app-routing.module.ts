import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdmissionComponent } from './admission/admission.component';
import { HomeDComponent } from './home-d/home-d.component';
import { LoginComponent } from './login/login.component';
import { NewsComponent } from './news/news.component';
import { StudenListComponent } from './studen-list/studen-list.component';

const routes: Routes = [
  {path:'',component:HomeDComponent},
  {path:'home',component:HomeDComponent},
  {path:'news',component:NewsComponent},
  {path:'addmision',component:AdmissionComponent},
  {path:'login',component:LoginComponent},
  {path:'Student-list',component:StudenListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
